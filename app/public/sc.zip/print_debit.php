<?php
    ob_start();
    //cek session
    session_start();

    if(empty($_SESSION['admin'])){
        $_SESSION['err'] = '<center>Anda harus login terlebih dahulu!</center>';
        header("Location: ./");
        die();
    } else 
?>


<?php
// memanggil library FPDF
require('library/fpdf.php');
require('include/config.php');

//function terbilang
function penyebut($nilai) {
    $nilai = abs($nilai);
    $huruf = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
    $temp = "";
    if ($nilai < 12) {
        $temp = " ". $huruf[$nilai];
    } else if ($nilai <20) {
        $temp = penyebut($nilai - 10). " belas";
    } else if ($nilai < 100) {
        $temp = penyebut($nilai/10)." puluh". penyebut($nilai % 10);
    } else if ($nilai < 200) {
        $temp = " seratus" . penyebut($nilai - 100);
    } else if ($nilai < 1000) {
        $temp = penyebut($nilai/100) . " ratus" . penyebut($nilai % 100);
    } else if ($nilai < 2000) {
        $temp = " seribu" . penyebut($nilai - 1000);
    } else if ($nilai < 1000000) {
        $temp = penyebut($nilai/1000) . " ribu" . penyebut($nilai % 1000);
    } else if ($nilai < 1000000000) {
        $temp = penyebut($nilai/1000000) . " juta" . penyebut($nilai % 1000000);
    } else if ($nilai < 1000000000000) {
        $temp = penyebut($nilai/1000000000) . " milyar" . penyebut(fmod($nilai,1000000000));
    } else if ($nilai < 1000000000000000) {
        $temp = penyebut($nilai/1000000000000) . " trilyun" . penyebut(fmod($nilai,1000000000000));
    }     
    return $temp;
}

function terbilang($nilai) {
    if($nilai<0) {
        $hasil = "minus ". trim(penyebut($nilai));
    } else {
        $hasil = trim(penyebut($nilai));
    }     		
    return $hasil;
}

// $bilangan_format = number_format($bilangan, 0, ',', '.');
//var_dump($_SESSION); //debugging send data
$jenis_surat = 'SURAT PENDEBITAN REKENING';
$no_surat = $_POST['no_surat'] ?? 'data tidak di input';
$date = $_POST['tanggal'] ?? 'data tidak di input';
$no_rekening = '55801300000533';
$jumlah = $_POST['jumlah'] ?? 'data tidak di input';

// intance object dan memberikan pengaturan halaman PDF
$pdf=new FPDF('P','mm','A4');
$pdf->AddPage();
 // Add the letterhead
 $pdf->SetMargins(25,25,20);
 
 $pdf->Image('upload/logo.png', 95, 9, 20); // posisi kiri,posisi atas,size
 $pdf->Cell(0, 25, '', 0, 1); // Add some space
 $pdf->SetFont('Arial', 'B', 12);

 $pdf->Cell(0, 5, 'SEKRETARIAT PANITIA PEMUNGUTAN SUARA DESA SINARLAUT', 0, 1, 'C');
 $pdf->Cell(0, 5, 'KECAMATAN AGRABINTA', 0, 1, 'C');
 $pdf->Cell(0, 5, 'KABUPATEN CIANJUR', 0, 1, 'C');
 $pdf->SetFont('Arial', 'I', 9);
 $pdf->Cell(0, 5, 'Alamat: Jl. Gelarwangi No. 1 Desa Sinarlaut Kec. Agrabinta - 43273', 0, 1, 'C');
 $pdf->SetLineWidth(1);
 $pdf->Line(25, 55, 185, 55); // Add a horizontal line

 $pdf->Cell(0, 5, '', 0, 1); // Add some space



// ubah format tanggal
$formatter = new IntlDateFormatter('id_ID' , IntlDateFormatter :: LONG, IntlDateFormatter :: NONE);

$tanggal = $formatter ->format(strtotime($date));

// Ambil nama hari
$hari = date('l', strtotime($date));

// Terjemahkan nama hari ke bahasa Indonesia (jika diperlukan)
$hari_indonesia = match ($hari) {
    'Monday' => 'Senin',
    'Tuesday' => 'Selasa',
    'Wednesday' => 'Rabu',
    'Thursday' => 'Kamis',
    'Friday' => 'Jumat',
    'Saturday' => 'Sabtu',
    'Sunday' => 'Minggu',
    default => $hari
};

$pdf->SetFont('Times', 'B', 15); // Mengatur font menjadi Arial Narrow, bold, dan ukuran 14
$pdf->Cell(0, 10, strtoupper($jenis_surat), 0, 1, 'C');
$pdf->SetFont('Arial','',10);
$pdf->MultiCell(160, 10, '  Tanggal : ' .$tanggal.' No. : '. $no_surat, 0, 'C');

$pdf->Cell(0, 5, '', 0, 1); // Add some space
$pdf->SetFont('arial','',10); 
$pdf->Cell(0, 5, 'Kepada Yth.', 0, 1); // Add some space
$cellWidth = 160;
$text = 'Pimpinan setempat  "PT. Bank Bank Tabungan Negara (Persero) Tbk. Cabang Cimahi"';
$pdf->MultiCell($cellWidth,  10, $text);
$pdf->Cell(0, 5, '', 0, 1); // Add some space
$text2 ='Saya yang bertanda tangan di bawah ini selaku Sekretaris PPS Desa Sinarlaut  memerintahkan Staff Urusan Keuangan  agar melakukan pendebitan tunai melalui teller bank yang Saudara pimpin dengan keterangan sebagai berikut :';
$pdf->MultiCell($cellWidth,  10, $text2);

$pdf->text(50,145,'Nomor Rekening     :  ' . $no_rekening,);
$pdf->text(50,155,'Nama Rekening	      : SEKRETARIAT PPS SINARLAUT KEC. AGRABINTA',);
$angka = number_format($jumlah);
$pdf->text(50,165,'Sejumlah                  :  ' . 'Rp. '. $angka,);

$terbilang = terbilang($jumlah);
$pdf->text(50,175,'Terbilang                  :  ' . strtoupper($terbilang). ' RUPIAH',);

$hari_ini = $hari_indonesia . ', ' . $tanggal;
$pdf->text(50,185,'Hari/Tanggal            :  ' . $hari_ini,);

$pdf->Cell(0, 55, '', 0, 1); // Add some space
$text3 ='Berkenaan dengan hal tersebut, mohon bantuan Saudara untuk membantu kelancaran transaksi dimaksud. Demikian disampaikan, atas bantuan dan kerjasama yang baik diucapkan terimakasih.';
$pdf->MultiCell($cellWidth,  10, $text3);
$pdf->MultiCell(160, 15, 'Cianjur, ' .$tanggal, 0, 'C');

$pdf->Cell(0, 10, '', 0, 1); // Add some space
$pdf->Rect(92, 237, 25, 15,);
$pdf->MultiCell(160, 10, 'Materai
Rp.10.000', 0, 'C');

$pdf->SetFont('arial','B',10);
$pdf->text(130, 230,'Staf Urusan Keuangan');
$pdf->text(60, 230,'Sekretaris');
$pdf->SetFont('arial','',10);
$pdf->text(130, 270,'(ASEP MAULANA)');
$pdf->text(60, 270,'(RIKAYAT)');

$nama_file = "Surat Pendebitan Rekening " . $tanggal . ".pdf";
if (isset($pdf)) {
    $pdf->Output('D',$nama_file);
} else {
    echo "Terjadi kesalahan dalam pembuatan PDF.";
}


unset ($no_surat);
unset ($date);
unset ($jumlah);

?>