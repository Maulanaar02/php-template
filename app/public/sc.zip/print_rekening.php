<?php
    ob_start();
    //cek session
    session_start();

    if(empty($_SESSION['admin'])){
        $_SESSION['err'] = '<center>Anda harus login terlebih dahulu!</center>';
        header("Location: ./");
        die();
    } else 
?>


<?php
// memanggil library FPDF
require('library/fpdf.php');
require('include/config.php');


// $bilangan_format = number_format($bilangan, 0, ',', '.');
//var_dump($_SESSION); //debugging send data
$jenis_surat = 'Permohonan Rekening Koran';
$no_rekening = '0144051262100';
$nama_rekening = 'PPS SINARLAUT KEC AGRABINTA';
$no_surat = $_POST['no_surat'] ?? 'data tidak di input';
$date = $_POST['tanggal'] ?? '10/26/2024';
$bulan = $_POST['bulan'] ?? 'data tidak di input';

// intance object dan memberikan pengaturan halaman PDF
$pdf=new FPDF('P','mm','A4');
$pdf->AddPage();
 // Add the letterhead
 $pdf->SetMargins(25,25,20);
 
 $pdf->Image('upload/logo.png', 25, 15, 20); // posisi kiri,posisi atas,size
 $pdf->Cell(0, 10, '', 0, 1); // Add some space
 $pdf->SetFont('Arial', 'B', 12);

 $pdf->Cell(0, 5, 'PANITIA PEMUNGUTAN SUARA DESA SINARLAUT', 0, 1, 'C');
 $pdf->Cell(0, 5, 'KECAMATAN AGRABINTA', 0, 1, 'C');
 $pdf->Cell(0, 5, 'KABUPATEN CIANJUR', 0, 1, 'C');
 $pdf->SetFont('Arial', 'I', 9);
 $pdf->Cell(0, 5, 'Alamat: Jl. Gelarwangi No. 1 Desa Sinarlaut Kecamatan Agrabinta - 43273', 0, 1, 'C');
 $pdf->SetLineWidth(1);
 $pdf->Line(25, 40, 185, 40); // Add a horizontal line

 $pdf->Cell(0, 5, '', 0, 1); // Add some space



// ubah format tanggal
$formatter = new IntlDateFormatter('id_ID' , IntlDateFormatter :: LONG, IntlDateFormatter :: NONE);

$tanggal = $formatter ->format(strtotime($date));

// Ambil nama hari
$hari = date('l', strtotime($date));

// Terjemahkan nama hari ke bahasa Indonesia (jika diperlukan)
$hari_indonesia = match ($hari) {
    'Monday' => 'Senin',
    'Tuesday' => 'Selasa',
    'Wednesday' => 'Rabu',
    'Thursday' => 'Kamis',
    'Friday' => 'Jumat',
    'Saturday' => 'Sabtu',
    'Sunday' => 'Minggu',
    default => $hari
};

$pdf->SetFont('Arial', '', 10); // Mengatur font menjadi Arial Narrow, bold, dan ukuran 14
$pdf->MultiCell(160, 10, 'Sinarlaut, '.$tanggal, 0,'R');

$pdf->Cell(0, 5, '', 0, 1); // Add some space
$pdf->SetFont('arial','',11); 
$pdf->MultiCell(160, 10, 'Nomor         : '.$no_surat, 0,1,);
$pdf->MultiCell(160, 10, 'Lampiran     : 1 (satu) Lembar', 0,1,);
$pdf->MultiCell(160, 10, 'Perihal         : '.$jenis_surat, 0,1,);

$pdf->Cell(0, 5, '', 0, 1); // Add some space
$cellWidth = 160;
$pdf->MultiCell($cellWidth,  10, 'Kepada Yth:');
$pdf->MultiCell($cellWidth,  10, 'KCP BJB Sindangbarang');
$pdf->MultiCell($cellWidth,  10, 'Di');
$pdf->MultiCell($cellWidth,  5, '            Tempat');
$pdf->Cell(0, 5, '', 0, 1); // Add some space

$pdf->SetFont('Arial','',11); 
$text ='Bersama ini kami sampaikan surat permohonan pencetakan Rekening Koran Bulan '.$bulan. ' 2024 dengan Nomor Rekening '.$no_rekening.' atas nama '.$nama_rekening;
$pdf->MultiCell($cellWidth,  10, $text);



$pdf->Cell(0, 5, '', 0, 1); // Add some space
$text1 ='Demikian permohonan ini kami sampaikan atas perhatian dan kerjasamanya kami ucapkan terimakasih.';
$pdf->MultiCell($cellWidth,  10, $text1);

//tanda tangan
$pdf->text(130, 210,'Sekretariat PPS Sinarlaut');
$pdf->SetFont('Times','B',12);
$pdf->text(145, 240,'Rikayat');


$nama_file = "Surat Pendebitan Rekening " . $tanggal . ".pdf";
if (isset($pdf)) {
// $pdf->Output();
    $pdf->Output('D',$nama_file);
} else {
    echo "Terjadi kesalahan dalam pembuatan PDF.";
}


unset ($no_surat);
unset ($date);
unset ($bulan);

?>