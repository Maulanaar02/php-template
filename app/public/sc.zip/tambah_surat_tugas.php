<?php

    //cek session
    if(empty($_SESSION['admin'])){
        $_SESSION['err'] = '<center>Anda harus login terlebih dahulu!</center>';
        header("Location: ./");
        die();
    } else {


            if(isset($_REQUEST['submit'])){

                //validasi form kosong
                if($_REQUEST['tanggal'] == "" || $_REQUEST['no_surat'] == ""|| $_REQUEST['nama'] == ""|| $_REQUEST['jabatan'] == ""|| $_REQUEST['tujuan'] == ""|| $_REQUEST['dalam_rangka'] == ""){
                    $_SESSION['errEmpty'] = 'ERROR! Semua form wajib diisi';
                    echo '<script language="javascript">window.history.back();</script>';
                } else {

                    $tanggal = $_REQUEST['tanggal'];
                    $no_surat = $_REQUEST['no_surat'];
                    $nama = $_REQUEST['nama'];
                    $jabatan = $_REQUEST['jabatan'];
                    $tujuan = $_REQUEST['tujuan'];
                    $dalam_rangka = $_REQUEST['dalam_rangka'];

                    //validasi input data
                    if(!preg_match("/^[a-zA-Z0-9. ]*$/", $tanggal)){
                            $_SESSION['tanggal'] = 'Form tanggal hanya boleh mengandung karakter huruf, angka, spasi dan titik(.)';
                            echo '<script language="javascript">window.history.back();</script>';
                        } else {

                            if(!preg_match("/^[a-zA-Z0-9. ]*$/", $no_surat)){
                                $_SESSION['no_surat'] = 'Form No Surat hanya boleh mengandung karakter huruf, angka, spasi dan titik(.)';
                                echo '<script language="javascript">window.history.back();</script>';
                        } else {

                        if(!preg_match("/^[a-zA-Z0-9.,\/ -]*$/", $nama)){
                            $_SESSION['nama'] = 'Form Nama hanya boleh mengandung karakter huruf, spasi, titik(.), koma(,) dan minus(-)';
                            echo '<script language="javascript">window.history.back();</script>';
                        } else {

                            if(!preg_match("/^[a-zA-Z0-9. ]*$/", $jabatan)){
                                $_SESSION['jabatan'] = 'Form jabatan hanya boleh mengandung karakter huruf, angka, spasi dan titik(.)';
                                echo '<script language="javascript">window.history.back();</script>';
                        } else {

                            if(!preg_match("/^[a-zA-Z0-9. ]*$/", $tujuan)){
                                $_SESSION['tujuan'] = 'Form tujuan hanya boleh mengandung karakter huruf, angka, spasi dan titik(.)';
                                echo '<script language="javascript">window.history.back();</script>';
                        } else {

                            if(!preg_match("/^[a-zA-Z0-9.,()\/\r\n -]*$/", $dalam_rangka)){
                                $_SESSION['dalam_rangka'] = 'Form Dalam Rangka hanya boleh mengandung karakter huruf, angka, spasi, titik(.), koma(,), minus(-), garis miring(/), dan kurung()';
                                echo '<script language="javascript">window.history.back();</script>';

                                } else {

                                  

                                    if($query != false){
                                        $_SESSION['succAdd'] = 'SUKSES! Data berhasil ditambahkan';
                                        header("Location: ./admin.php?");
                                        die();
                                    } else {
                                        $_SESSION['errQ'] = 'ERROR! Ada masalah dengan query';
                                        echo '<script language="javascript">window.history.back();</script>';
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
           ?>
                <!-- Row Start -->
                <div class="row">
                    <!-- Secondary Nav START -->
                    <div class="col s12">
                        <nav class="secondary-nav">
                            <div class="nav-wrapper blue-grey darken-1">
                                <ul class="left">
                                    <li class="waves-effect waves-light"><a href="?page=creat&act=tgs" class="judul"><i class="material-icons">bookmark</i> Buat Surat Tugas</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                    <!-- Secondary Nav END -->
                </div>
                <!-- Row END -->

                <?php
                    if(isset($_SESSION['errQ'])){
                        $errQ = $_SESSION['errQ'];
                        echo '<div id="alert-message" class="row">
                                <div class="col m12">
                                    <div class="card red lighten-5">
                                        <div class="card-content notif">
                                            <span class="card-title red-text"><i class="material-icons md-36">clear</i> '.$errQ.'</span>
                                        </div>
                                    </div>
                                </div>
                            </div>';
                        unset($_SESSION['errQ']);
                    }
                    if(isset($_SESSION['errEmpty'])){
                        $errEmpty = $_SESSION['errEmpty'];
                        echo '<div id="alert-message" class="row">
                                <div class="col m12">
                                    <div class="card red lighten-5">
                                        <div class="card-content notif">
                                            <span class="card-title red-text"><i class="material-icons md-36">clear</i> '.$errEmpty.'</span>
                                        </div>
                                    </div>
                                </div>
                            </div>';
                        unset($_SESSION['errEmpty']);
                    }
                ?>

                <!-- Row form Start -->
                <div class="row jarak-form">

                    <!-- Form START -->
                    <form class="col s12" method="post" action="print_tugas.php">

                        <!-- Row in form START -->
                        <div class="row">
                        
    <div class="input-field col s6">
        <i class="material-icons prefix md-prefix">text_fields</i>
        <input id="no_surat" type="text" class="validate" name="no_surat" required>
        <label for="no_surat">Nomor Surat</label>

    </div>
    <div class="input-field col s6">
        <i class="material-icons prefix md-prefix">date_range</i>
        <input id="tanggal" type="date" class="datepicker" name="tanggal" required>
        <label for="tanggal"></label>
    </div>
    <div class="input-field col s6">
        <i class="material-icons prefix md-prefix">text_fields</i>
        <input id="jabatan" type="text" class="validate" name="jabatan" required>
        <label for="jabatan">Jabatan</label>

    </div>
    <div class="input-field col s6">
        <i class="material-icons prefix md-prefix">text_fields</i>
        <input id="tujuan" type="text" class="validate" name="tujuan" required>
        <label for="tujuan">Tujuan</label>

    </div>
    <div class="input-field col s6">
        <i class="material-icons prefix md-prefix">text_fields</i>
        <input id="nama" type="text" class="validate" name="nama" required>   

        <label for="nama">Nama</label>

    </div>
    <div class="input-field col s12">
        <i class="material-icons prefix md-prefix">subject</i>
        <textarea id="dalam_rangka" class="materialize-textarea" name="dalam_rangka" required></textarea>
        <label for="dalam_rangka">Dalam Rangka</label>


                            </div>
                        </div>
                        <!-- Row in form END -->
                        <div class="row">
                            <div class="col 6">
                                <button type="submit" name="submit" class="btn-large blue waves-effect waves-light">SIMPAN <i class="material-icons">done</i></button>
                            </div>
                            <div class="col 6">
                                <a href="?page=creat" class="btn-large deep-orange waves-effect waves-light">BATAL <i class="material-icons">clear</i></a>
                            </div>
                        </div>

                    </form>
                    <!-- Form END -->

                </div>
                <!-- Row form END -->

<?php
            
// var_dump($_REQUEST)
?>
