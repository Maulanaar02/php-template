<?php
echo '
<div class="thumbnail">
<a><b>MOHON MAAF FITUR BELUM TERSEDIA!!</b></a>
<a href="?page=creat" class="btn-large deep-orange waves-effect waves-light">Kembali<i class="material-icons">clear</i></a>
</div>';
?>
<style>
.thumbnail {
    float: left;
    width: 300px;
    height: 50px;
    background-color: #f0f0f0;
    border: 1px solid #ccc;
    border-radius: 10px;
    margin: 100px;
    text-align: center;
    transition: all 0.3s ease-in-out;
}
.thumbnail a {
    width:300px;
    height: 50px;
}
</style>