<?php
    ob_start();
    //cek session
    session_start();

    if(empty($_SESSION['admin'])){
        $_SESSION['err'] = '<center>Anda harus login terlebih dahulu!</center>';
        header("Location: ./");
        die();
    } else {
?>


<?php
// memanggil library FPDF
require('library/fpdf.php');
require('include/config.php');



//var_dump($_POST); //debugging send data
$jenis_surat = 'SURAT TUGAS';
$no_surat = $_POST['no_surat'] ?? 'Data tidak ditemukan';
$date = $_POST['tanggal'] ?? 'Data tidak ditemukan';
$jabatan = $_POST['jabatan'] ?? 'Data tidak ditemukan';
$tujuan = $_POST['tujuan'] ?? 'Data tidak ditemukan';
$nama = $_POST['nama'] ?? 'Data tidak ditemukan';
$dalam_rangka = $_POST['dalam_rangka'] ?? 'Data tidak ditemukan';

// intance object dan memberikan pengaturan halaman PDF
$pdf=new FPDF('P','mm','A4');
$pdf->AddPage();
 // Add the letterhead
 $pdf->SetMargins(25,25,20);
 $pdf->SetFont('Arial', '', 12);

 $pdf->Rect(160, 10, 30, 8,);
 $pdf->Text(165, 15, 'HIBAH.18');
 
 $pdf->Image('upload/logo.png', 95, 15, 20); // Adjust position and size as needed
 $pdf->Cell(0, 30, '', 0, 1); // Add some space
 $pdf->SetFont('Arial', 'B', 12);

 $pdf->Cell(0, 5, 'PANITIA PEMUNGUTAN SUARA DESA SINARLAUT', 0, 1, 'C');
 $pdf->Cell(0, 5, 'KECAMATAN AGRABINTA', 0, 1, 'C');
 $pdf->Cell(0, 5, 'KABUPATEN CIANJUR', 0, 1, 'C');
 $pdf->SetFont('Arial', 'I', 9);
 $pdf->Cell(0, 5, 'Alamat: Jl. Gelarwangi No. 1 Desa Sinarlaut Kec. Agrabinta - 43273', 0, 1, 'C');
 $pdf->SetLineWidth(1);
 $pdf->Line(25, 60, 185, 60); // Add a horizontal line

 $pdf->Cell(0, 5, '', 0, 1); // Add some space



// ubah format tanggal
$formatter = new IntlDateFormatter('id_ID' , IntlDateFormatter :: LONG, IntlDateFormatter :: NONE);

$tanggal = $formatter ->format(strtotime($date));

$pdf->SetFont('Times','',10);
$pdf->SetFont('Times', 'B', 14); // Mengatur font menjadi Arial Narrow, bold, dan ukuran 14
$pdf->Cell(0, 5, strtoupper($jenis_surat), 0, 1, 'C');
$pdf->SetFont('Times','',12);
$pdf->MultiCell(0, 5, '  Nomor : ' . $no_surat, 0, 'C');

$pdf->Cell(0, 5, '', 0, 1); // Add some space
$pdf->SetFont('Times','',12);
$cellWidth = 160;
$text = "Yang bertanda tangan di bawah ini Ketua PPS Desa Sinarlaut, dengan ini memberikan tugas kepada :";
$pdf->MultiCell($cellWidth,  10, $text);

$pdf->MultiCell(0, 10, ' 1. Nama        : ' . strtoupper($nama), 0,);
$pdf->MultiCell(0, 5, '     Jabatan     : ' . strtoupper($jabatan), 0,);

$pdf->Cell(0, 5, '', 0, 1); // Add some space
$pdf->MultiCell($cellWidth,  10,'Untuk melaksanakan tugas ke '. $tujuan .' yang akan dilaksanakan :');
$pdf->MultiCell(0, 10, 'Tanggal                : ' . $tanggal, 0,);
$pdf->MultiCell(0, 10, 'Dalam Rangka     : ' . $dalam_rangka, 0,);
$pdf->MultiCell($cellWidth,  10,'Demikian surat tugas ini dibuat untuk dapat dilaksanakan sebagaimana mestinya.');

$pdf->text(135, 190,'Ditetapkan Di : Sinarlaut');
$pdf->text(135, 200,'KETUA PPS');
$pdf->SetFont('Times','B',12);
$pdf->text(135, 230,'AGUS SAEPUDIN');

$nama_file = "Surat Tugas " . $tanggal . ".pdf";
if (isset($pdf)) {
    $pdf->Output('D',$nama_file);
} else {
    echo "Terjadi kesalahan dalam pembuatan PDF.";
}

unset ($no_surat);
unset ($date);
unset ($jabata);
unset ($tujuan);
unset ($nama);
unset ($dalam_rangka);
unset ($nama_file);
    }
?>