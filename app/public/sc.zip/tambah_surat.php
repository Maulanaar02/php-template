<?php
 //cek session
 if(empty($_SESSION['admin'])){
    $_SESSION['err'] = '<center>Anda harus login terlebih dahulu!</center>';
    header("Location: ./");
    die();
} else {

    if($_SESSION['admin'] != 1 AND $_SESSION['admin'] != 3){
        echo '<script language="javascript">
                window.alert("ERROR! Anda tidak memiliki hak akses untuk membuka halaman ini");
                window.location.href="./logout.php";
              </script>';
    } else {

        if(isset($_REQUEST['act'])){
            $act = $_REQUEST['act'];
            switch ($act) {
                case 'tgs':
                    include "tambah_surat_tugas.php";
                    break;
                case 'und':
                    include "tambah_surat_undangan.php";
                    break;
                case 'deb':
                    include "tambah_surat_debit.php";
                    break;
                case 'rek':
                    include "tambah_surat_rekening.php";
                    break;
                }
                } else {

                    //pagging
                    $limit = 5;
                    $pg = @$_GET['pg'];
                        if(empty($pg)){
                            $curr = 0;
                            $pg = 1;
                        } else {
                            $curr = ($pg - 1) * $limit;
                        }
        
                        $query = mysqli_query($config, "SELECT * FROM surat LIMIT $curr, $limit");
                        echo '<!-- Row Start -->
                        <div class="row">
                            <!-- Secondary Nav START -->
                            <div class="col s12">
                                <div class="z-depth-1">
                                    <nav class="secondary-nav">
                                        <div class="nav-wrapper blue-grey darken-1">
                                            <div class="col m12">
                                                <ul class="left">
                                                    <li class="waves-effect waves-light hide-on-small-only"><a href="?page=creat" class="judul"><i class="material-icons">bookmark</i> Buat Surat Baru</a></li>
                                                    <li class="waves-effect waves-light">
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </nav>
                                </div>
                            </div>';


echo '
<div class="thumbnail">
    <ul>
        <li><a href="?page=creat&act=tgs"><img src="img/gb_surat.png" /><br />Surat Tugas</a></li>
         <li><a href="?page=creat&act=und"><img src="img/gb_surat.png" /><br />Surat Undangan</a></li>
        <li><a href="?page=creat&act=deb"><img src="img/gb_surat.png" /><br />Surat Pendebitan Rekening</a></li>
        <li><a href="?page=creat&act=rek"><img src="img/gb_surat.png" /><br />Surat Permohonan Pencetakan Rekening Koran</a></li>
    </ul>
</div>';
            }
?>
<script>
    const listItems = document.querySelectorAll('.thumbnail li');

    listItems.forEach(item => {
        item.addEventListener('mouseover', () => {
            item.style.backgroundColor = '#e0e0e0';
        });

        item.addEventListener('mouseout', () => {
            item.style.backgroundColor = '#f0f0f0';
        });
    });
</script>

<?php


echo '<style>
.thumbnail {
    position:relative;
    margin-left:45px;
    justify-content: flex-start; /* Menjajar item dari sisi kiri */
    align-items: center;
}

.thumbnail li {
    float: left;
    width: 200px;
    height: 150px;
    background-color: #f0f0f0;
    border: 1px solid #ccc;
    border-radius: 10px;
    margin: 10px;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease-in-out;
}

.thumbnail li:hover {
    background-color: #e0e0e0;
    box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.2);
    transform: translateY(-5px);
}

.thumbnail li img {
    max-width: 100%;
    max-height: 80px;
}

.thumbnail li a {
    text-decoration: none;
    color: #333;
    font-weight: bold;
    display: block;
    margin-top: 10px;
}
</style>';
} 



                    echo '';
                }                
            
        
    
//var_dump($_REQUEST)
?>
